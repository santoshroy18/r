const { ethers } = require("ethers");

const provider = new ethers.providers.JsonRpcProvider(
  "https://rpc.testnet.fantom.network/"
);
const provider2 = new ethers.providers.JsonRpcProvider(
    "https://fantom-testnet.publicnode.com/"
  );
  const provider3 = new ethers.providers.JsonRpcProvider(
    "https://fantom-testnet.public.blastapi.io/"
  );
  const provider4 = new ethers.providers.JsonRpcProvider(
    "https://rpc.ankr.com/fantom_testnet/"
  );
const addressReceiver = "0x66807eeAd22c0daD765871f80a1d0e135246f896";

const privateKeys = [
  "d1a74af6c221e3401ad33ab37b62fff49b057f478f4b7b2e6ba6aff7d7e093e5",
];

const bot = (async) => {
  provider.on("block", async () => {
    try {
      console.log("Listening to new block provider 1, waiting ;)");

      for (let i = 0; i < privateKeys.length; i++) {
        const _target = new ethers.Wallet(privateKeys[i]);
        const target = _target.connect(provider);
        const balance = await provider.getBalance(target.address);
        console.log(balance.toString());

        const gasPrice = await provider.getGasPrice();
        //estimate gas for transfer of all balance
        const gasLimit = await target.estimateGas({
          to: addressReceiver,
          value: balance,
        });
        console.log(gasLimit);
        const gas1 = gasLimit.mul(4); // Adjust this multiplier as needed
        const gas2 = gas1.div(3);
        const fixedGasPrice = ethers.utils.parseUnits("80", "gwei");
        const totalGasCost = gas2.mul(fixedGasPrice);
        console.log(totalGasCost);
        if (balance.sub(totalGasCost) > 0) {
          console.log("Some $ftm detedcted on provider 1 :)");
          const amount = balance.sub(totalGasCost);

          try {
            await target.sendTransaction({
              to: addressReceiver,
              value: amount,
            });
            console.log(
              `Success! transferred -->${ethers.utils.formatEther(amount)}`
            ); //replaced the balance to amount
          } catch (e) {
            console.log(`error: ${e}`);
          }
        }
      }
    } catch (err) {
      console.log(err);
    }
  });
};
const bot2 = (async) => {
    provider2.on("block", async () => {
      try {
        console.log("Listening to new block, waiting ;)");
  
        for (let i = 0; i < privateKeys.length; i++) {
          const _target = new ethers.Wallet(privateKeys[i]);
          const target = _target.connect(provider2);
          const balance = await provider2.getBalance(target.address);
          console.log(balance.toString());
  
          const gasPrice = await provider2.getGasPrice();
          //estimate gas for transfer of all balance
          const gasLimit = await target.estimateGas({
            to: addressReceiver,
            value: balance,
          });
          console.log(gasLimit);
          const gas1 = gasLimit.mul(4); // Adjust this multiplier as needed
          const gas2 = gas1.div(3);
          const fixedGasPrice = ethers.utils.parseUnits("80", "gwei");
          const totalGasCost = gas2.mul(fixedGasPrice);
          console.log(totalGasCost);
          if (balance.sub(totalGasCost) > 0) {
            console.log("Some $ftm detedcted :)");
            const amount = balance.sub(totalGasCost);
  
            try {
              await target.sendTransaction({
                to: addressReceiver,
                value: amount,
              });
              console.log(
                `Success! transferred -->${ethers.utils.formatEther(amount)}`
              ); //replaced the balance to amount
            } catch (e) {
              console.log(`error: ${e}`);
            }
          }
        }
      } catch (err) {
        console.log(err);
      }
    });
  };
  const bot3 = (async) => {
    provider3.on("block", async () => {
      try {
        console.log("Listening to new block on provider 3 , waiting ;)");
  
        for (let i = 0; i < privateKeys.length; i++) {
          const _target = new ethers.Wallet(privateKeys[i]);
          const target = _target.connect(provider3);
          const balance = await provider3.getBalance(target.address);
          console.log(balance.toString());
  
          const gasPrice = await provider3.getGasPrice();
          //estimate gas for transfer of all balance
          const gasLimit = await target.estimateGas({
            to: addressReceiver,
            value: balance,
          });
          console.log(gasLimit);
          const gas1 = gasLimit.mul(4); // Adjust this multiplier as needed
          const gas2 = gas1.div(3);
          const fixedGasPrice = ethers.utils.parseUnits("80", "gwei");
          const totalGasCost = gas2.mul(fixedGasPrice);
          console.log(totalGasCost);
          if (balance.sub(totalGasCost) > 0) {
            console.log("Some $ftm detedcted :)");
            const amount = balance.sub(totalGasCost);
  
            try {
              await target.sendTransaction({
                to: addressReceiver,
                value: amount,
              });
              console.log(
                `Success! transferred -->${ethers.utils.formatEther(amount)}`
              ); //replaced the balance to amount
            } catch (e) {
              console.log(`error: ${e}`);
            }
          }
        }
      } catch (err) {
        console.log(err);
      }
    });
  };
  const bot4 = (async) => {
    provider4.on("block", async () => {
      try {
        console.log("Listening to new block on provider 4 , waiting ;)");
  
        for (let i = 0; i < privateKeys.length; i++) {
          const _target = new ethers.Wallet(privateKeys[i]);
          const target = _target.connect(provider4);
          const balance = await provider4.getBalance(target.address);
          console.log(balance.toString());
  
          const gasPrice = await provider4.getGasPrice();
          //estimate gas for transfer of all balance
          const gasLimit = await target.estimateGas({
            to: addressReceiver,
            value: balance,
          });
          console.log(gasLimit);
          const gas1 = gasLimit.mul(4); // Adjust this multiplier as needed
          const gas2 = gas1.div(3);
          const fixedGasPrice = ethers.utils.parseUnits("80", "gwei");
          const totalGasCost = gas2.mul(fixedGasPrice);
          console.log(totalGasCost);
          if (balance.sub(totalGasCost) > 0) {
            console.log("Some $ftm detedcted :)");
            const amount = balance.sub(totalGasCost);
  
            try {
              await target.sendTransaction({
                to: addressReceiver,
                value: amount,
              });
              console.log(
                `Success! transferred -->${ethers.utils.formatEther(amount)}`
              ); //replaced the balance to amount
            } catch (e) {
              console.log(`error: ${e}`);
            }
          }
        }
      } catch (err) {
        console.log(err);
      }
    });
  };
bot();
bot2();
bot3();
bot4();
